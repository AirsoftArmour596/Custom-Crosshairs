Custom Crosshairs - Version 0.00.3

Struggling to keep your eye on the center of your screen? Or maybe you want to destroy your enemies
with compliete precision in games otherwise designed to prevent such? Then this is the program for you!
Select from a variety of preset crosshairs or even make your own to personalise the center of the screen!

/ / / / / / / / / / Devlog \ \ \ \ \ \ \ \ \ \ 
V0.00.3, "Hellfire";
Uploaded to Gitgub for the first time
Added Main Menu
Added Framework for the Settings Menu
